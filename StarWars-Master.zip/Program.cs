﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net;
using System.Text;

namespace StarWars
{
    class Program

    {
        const string BASE_URL = "https://swapi.co/api/";
        static void Main(string[] args)
        {
            const string PLANETS = "planets/";
            //const string PEOPLE = "people/";
            string page = "?page=";
            int pageNumber = 1;
            bool runloop = false;


            //Console.WriteLine(CallRestMethod(new Uri(BASE_URL + PLANETS)));
            //Console.WriteLine(CallRestMethod(new Uri(BASE_URL + PEOPLE)));

            var callNext = CallRestMethod(new Uri(BASE_URL + PLANETS + page + pageNumber));
            //var count = Int32.Parse(callNext["count"].ToString());
            if (callNext["next"].Type != JTokenType.Null)
            {
                runloop = true;
            }

            while (runloop)
            {
                callNext = CallRestMethod(new Uri(BASE_URL + PLANETS + page + pageNumber));
                JArray array = (JArray)callNext["results"];

                if(callNext["next"].Type == JTokenType.Null)
                {
                    runloop = false;
                }

                for (int i = 0; i < array.Count; i++)
                {
                    var next = array[i]["name"].ToString();
                    var films = array[i]["films"].ToString();
                    Console.WriteLine(next + films);
                }
                pageNumber++;
            }
            Console.ReadLine();
        }

        static JObject CallRestMethod(Uri uri)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                StreamReader stream = new StreamReader(response.GetResponseStream(), Encoding.UTF8);

                JObject result = JObject.Parse(stream.ReadToEnd());
                response.Close();
                stream.Close();
                return result;
            }
            catch (Exception e)
            {
                string result = $"{{'Error':'Error occured. Could not get {uri.LocalPath}','Message':'{e.Message}'}}";
                return JObject.Parse(result);
            }
        }

    }
}
