﻿using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net;
using System.Text;

namespace StarWars
{
    class Program
    {
        const string BASE_URL = "https://swapi.co/api/";
        static void Main(string[] args)
        {
            const string PLANETS = "planets/";
            string page = "?page=";
            int pageNumber = 1;

            while (true)
            {
                var callNext = callRestMethod(new Uri(BASE_URL + PLANETS + page + pageNumber));
                JArray array = (JArray)callNext["results"];

                for (int i = 0; i < array.Count; i++)
                {
                    Console.WriteLine(array[i]["name"].ToString());

                    string[] filmNames = array[i]["films"].ToObject<string[]>();
                    if (filmNames.Length > 0)
                    {
                        foreach (JValue filmUrl in array[i]["films"])
                        {
                            var film = callRestMethod(new Uri(filmUrl.ToString()));
                            Console.WriteLine(film["title"]);
                        }
                    }
                    else {
                        Console.WriteLine("Pretty sure this planet wasn't featured in any Star Wars films.");
                    }
                }

                if (callNext["next"].Type != JTokenType.Null)
                    pageNumber++;
                else
                    break;
            }
            Console.ReadLine();
        }
        static JObject callRestMethod(Uri uri)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                StreamReader stream = new StreamReader(response.GetResponseStream(), Encoding.UTF8);

                JObject result = JObject.Parse(stream.ReadToEnd());
                response.Close();
                stream.Close();
                return result;
            }
            catch (Exception e)
            {
                string result = $"{{'Error':'Error occurred.  Could not get {uri.LocalPath}', 'Message':'{e.Message}'}}";
                return JObject.Parse(result);
            }
        }
    }
}
